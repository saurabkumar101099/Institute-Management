package com.spiders.softwaretrainingspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoftwareTrainingSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
